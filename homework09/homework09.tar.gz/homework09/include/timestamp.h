/* timestamp.h */

#pragma once

/* Functions */

double	timestamp();

/* vim: set expandtab sts=4 sw=4 ts=8 ft=c: */
