# Homework 09

timestamp.c

    double      timestamp();
    
socket.c

    FILE *      socket_dial(const char *host, const char *port);

request.c
    
    typedef struct {
        char   *host;
        char   *port;
        char   *path;
        char   *text;
        size_t  size;
    } Request;
    
    Request *   request_create(const char *url);
    bool        request_get(Request *request);
    void        request_delete(Request *request);
   
hammer.c

    bool        hammer(const char *url);
    
throw.c

    bool        throw(const char *url, size_t hammers);
